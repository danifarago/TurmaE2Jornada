Apenas para complementar as aulas sobre a propriedade position.
